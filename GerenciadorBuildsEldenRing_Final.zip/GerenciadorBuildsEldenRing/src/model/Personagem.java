package model;

public class Personagem {

    private int id;
    private String classe;          // Ex: Samurai, Astrologer, Vagabond...
    private int nivel;

    // Atributos do Elden Ring
    private int vigor;
    private int mind;
    private int endurance;
    private int strength;
    private int dexterity;
    private int intelligence;
    private int faith;
    private int arcane;

    // Construtor vazio
    public Personagem() {
    }

    // Construtor completo
    public Personagem(String classe, int nivel, int vigor, int mind, int endurance,
                      int strength, int dexterity, int intelligence, int faith, int arcane) {
        this.classe = classe;
        this.nivel = nivel;
        this.vigor = vigor;
        this.mind = mind;
        this.endurance = endurance;
        this.strength = strength;
        this.dexterity = dexterity;
        this.intelligence = intelligence;
        this.faith = faith;
        this.arcane = arcane;
    }

    // Getters e Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getClasse() {
        return classe;
    }

    public void setClasse(String classe) {
        this.classe = classe;
    }

    public int getNivel() {
        return nivel;
    }

    public void setNivel(int nivel) {
        this.nivel = nivel;
    }

    public int getVigor() {
        return vigor;
    }

    public void setVigor(int vigor) {
        this.vigor = vigor;
    }

    public int getMind() {
        return mind;
    }

    public void setMind(int mind) {
        this.mind = mind;
    }

    public int getEndurance() {
        return endurance;
    }

    public void setEndurance(int endurance) {
        this.endurance = endurance;
    }

    public int getStrength() {
        return strength;
    }

    public void setStrength(int strength) {
        this.strength = strength;
    }

    public int getDexterity() {
        return dexterity;
    }

    public void setDexterity(int dexterity) {
        this.dexterity = dexterity;
    }

    public int getIntelligence() {
        return intelligence;
    }

    public void setIntelligence(int intelligence) {
        this.intelligence = intelligence;
    }

    public int getFaith() {
        return faith;
    }

    public void setFaith(int faith) {
        this.faith = faith;
    }

    public int getArcane() {
        return arcane;
    }

    public void setArcane(int arcane) {
        this.arcane = arcane;
    }

    @Override
    public String toString() {
        return "Classe: " + classe + " | Nível: " + nivel +
               "\nVigor: " + vigor + " | Mind: " + mind + " | Endurance: " + endurance +
               "\nStrength: " + strength + " | Dexterity: " + dexterity +
               "\nIntelligence: " + intelligence + " | Faith: " + faith + " | Arcane: " + arcane;
    }
}
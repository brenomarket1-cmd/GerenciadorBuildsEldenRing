package model;

import java.util.ArrayList;
import java.util.List;

public class Build {

    private int id;
    private String nomeBuild;
    private Personagem personagem;
    private List<Equipamento> equipamentos;
    private String observacoes;

    // Construtor vazio
    public Build() {
        this.equipamentos = new ArrayList<>();
    }

    // Construtor completo
    public Build(String nomeBuild, Personagem personagem, String observacoes) {
        this.nomeBuild = nomeBuild;
        this.personagem = personagem;
        this.observacoes = observacoes;
        this.equipamentos = new ArrayList<>();
    }

    // Getters e Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNomeBuild() {
        return nomeBuild;
    }

    public void setNomeBuild(String nomeBuild) {
        this.nomeBuild = nomeBuild;
    }

    public Personagem getPersonagem() {
        return personagem;
    }

    public void setPersonagem(Personagem personagem) {
        this.personagem = personagem;
    }

    public List<Equipamento> getEquipamentos() {
        return equipamentos;
    }

    public void setEquipamentos(List<Equipamento> equipamentos) {
        this.equipamentos = equipamentos;
    }

    public String getObservacoes() {
        return observacoes;
    }

    public void setObservacoes(String observacoes) {
        this.observacoes = observacoes;
    }

    // Métodos auxiliares
    public void adicionarEquipamento(Equipamento equipamento) {
        this.equipamentos.add(equipamento);
    }

    public void removerEquipamento(Equipamento equipamento) {
        this.equipamentos.remove(equipamento);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("========== BUILD: ").append(nomeBuild).append(" ==========\n");
        sb.append(personagem.toString()).append("\n");
        sb.append("----- Equipamentos -----\n");
        
        if (equipamentos.isEmpty()) {
            sb.append("Nenhum equipamento cadastrado.\n");
        } else {
            for (Equipamento eq : equipamentos) {
                sb.append("• ").append(eq.getDescricaoCompleta()).append("\n");
            }
        }
        
        sb.append("Observações: ").append(observacoes != null ? observacoes : "Nenhuma");
        sb.append("\n====================================");
        return sb.toString();
    }
}
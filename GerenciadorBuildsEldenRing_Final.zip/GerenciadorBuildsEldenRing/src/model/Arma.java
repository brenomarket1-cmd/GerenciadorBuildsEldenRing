package model;

public class Arma extends Equipamento {

    private String categoria;

    public Arma() {
        super();
        setTipo("Arma");
    }

    public Arma(String nome, String categoria) {
        super(nome, "Arma");
        this.categoria = categoria;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    @Override
    public String getDetalhe() {
        return categoria;
    }

    @Override
    public String getDescricaoCompleta() {
        return "Arma: " + getNome() + " (" + categoria + ")";
    }
}
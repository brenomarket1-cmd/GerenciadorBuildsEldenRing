package model;

public class Armadura extends Equipamento {

    private String parte;

    public Armadura() {
        super();
        setTipo("Armadura");
    }

    public Armadura(String nome, String parte) {
        super(nome, "Armadura");
        this.parte = parte;
    }

    public String getParte() {
        return parte;
    }

    public void setParte(String parte) {
        this.parte = parte;
    }

    @Override
    public String getDetalhe() {
        return parte;
    }

    @Override
    public String getDescricaoCompleta() {
        return "Armadura: " + getNome() + " (" + parte + ")";
    }
}
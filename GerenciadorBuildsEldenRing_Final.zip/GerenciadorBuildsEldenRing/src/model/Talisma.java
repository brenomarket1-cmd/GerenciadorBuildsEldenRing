package model;

public class Talisma extends Equipamento {

    private String efeito;

    public Talisma() {
        super();
        setTipo("Talisma");
    }

    public Talisma(String nome, String efeito) {
        super(nome, "Talisma");
        this.efeito = efeito;
    }

    public String getEfeito() {
        return efeito;
    }

    public void setEfeito(String efeito) {
        this.efeito = efeito;
    }

    @Override
    public String getDetalhe() {
        return efeito;
    }

    @Override
    public String getDescricaoCompleta() {
        return "Talisma: " + getNome() + " - Efeito: " + efeito;
    }
}
package dao;

import model.*;
import util.Conexao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BuildDAO implements IBuildDAO {

    public BuildDAO() {
        criarTabelas();
    }

    private void criarTabelas() {
        String sqlPersonagem = """
            CREATE TABLE IF NOT EXISTS personagem (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                classe TEXT NOT NULL,
                nivel INTEGER,
                vigor INTEGER,
                mind INTEGER,
                endurance INTEGER,
                strength INTEGER,
                dexterity INTEGER,
                intelligence INTEGER,
                faith INTEGER,
                arcane INTEGER
            );
            """;

        String sqlBuild = """
            CREATE TABLE IF NOT EXISTS build (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nome_build TEXT NOT NULL,
                personagem_id INTEGER,
                observacoes TEXT,
                FOREIGN KEY (personagem_id) REFERENCES personagem(id)
            );
            """;

        String sqlEquipamento = """
            CREATE TABLE IF NOT EXISTS equipamento (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nome TEXT NOT NULL,
                tipo TEXT NOT NULL,
                detalhe TEXT,
                build_id INTEGER,
                FOREIGN KEY (build_id) REFERENCES build(id) ON DELETE CASCADE
            );
            """;

        try (Connection conn = Conexao.getConexao();
             Statement stmt = conn.createStatement()) {
            stmt.execute(sqlPersonagem);
            stmt.execute(sqlBuild);
            stmt.execute(sqlEquipamento);
        } catch (SQLException e) {
            System.out.println("Erro ao criar tabelas: " + e.getMessage());
        }
    }

    @Override
    public void cadastrar(Build build) throws Exception {
        Connection conn = null;
        try {
            conn = Conexao.getConexao();
            conn.setAutoCommit(false);

            // 1. Inserir Personagem
            String sqlPersonagem = """
                INSERT INTO personagem (classe, nivel, vigor, mind, endurance, strength, dexterity, intelligence, faith, arcane)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """;
            PreparedStatement psPersonagem = conn.prepareStatement(sqlPersonagem, Statement.RETURN_GENERATED_KEYS);
            Personagem p = build.getPersonagem();
            psPersonagem.setString(1, p.getClasse());
            psPersonagem.setInt(2, p.getNivel());
            psPersonagem.setInt(3, p.getVigor());
            psPersonagem.setInt(4, p.getMind());
            psPersonagem.setInt(5, p.getEndurance());
            psPersonagem.setInt(6, p.getStrength());
            psPersonagem.setInt(7, p.getDexterity());
            psPersonagem.setInt(8, p.getIntelligence());
            psPersonagem.setInt(9, p.getFaith());
            psPersonagem.setInt(10, p.getArcane());
            psPersonagem.executeUpdate();

            ResultSet rs = psPersonagem.getGeneratedKeys();
            int personagemId = 0;
            if (rs.next()) {
                personagemId = rs.getInt(1);
            }

            // 2. Inserir Build
            String sqlBuild = "INSERT INTO build (nome_build, personagem_id, observacoes) VALUES (?, ?, ?)";
            PreparedStatement psBuild = conn.prepareStatement(sqlBuild, Statement.RETURN_GENERATED_KEYS);
            psBuild.setString(1, build.getNomeBuild());
            psBuild.setInt(2, personagemId);
            psBuild.setString(3, build.getObservacoes());
            psBuild.executeUpdate();

            ResultSet rsBuild = psBuild.getGeneratedKeys();
            int buildId = 0;
            if (rsBuild.next()) {
                buildId = rsBuild.getInt(1);
                build.setId(buildId);
            }

            // 3. Inserir Equipamentos
            String sqlEquip = "INSERT INTO equipamento (nome, tipo, detalhe, build_id) VALUES (?, ?, ?, ?)";
            PreparedStatement psEquip = conn.prepareStatement(sqlEquip);

            for (Equipamento eq : build.getEquipamentos()) {
                psEquip.setString(1, eq.getNome());
                psEquip.setString(2, eq.getTipo());

                String detalhe = "";

                if (eq.getTipo().equalsIgnoreCase("Arma")) {
                    detalhe = ((Arma) eq).getCategoria();
                } else if (eq.getTipo().equalsIgnoreCase("Armadura")) {
                    detalhe = ((Armadura) eq).getParte();
                } else if (eq.getTipo().equalsIgnoreCase("Talisma")) {
                    detalhe = ((Talisma) eq).getEfeito();
                }

                psEquip.setString(3, detalhe);
                psEquip.setInt(4, buildId);
                psEquip.executeUpdate();
            }

            conn.commit();

        } catch (SQLException e) {
            if (conn != null) conn.rollback();
            throw new Exception("Erro ao cadastrar build: " + e.getMessage());
        } finally {
            if (conn != null) conn.setAutoCommit(true);
        }
    }

    @Override
    public void atualizar(Build build) throws Exception {
        excluir(build.getId());
        cadastrar(build);
    }

    @Override
    public void excluir(int id) throws Exception {
        String sql = "DELETE FROM build WHERE id = ?";
        try (Connection conn = Conexao.getConexao();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            int linhas = ps.executeUpdate();
            if (linhas == 0) {
                throw new Exception("Build com ID " + id + " não encontrada.");
            }
        } catch (SQLException e) {
            throw new Exception("Erro ao excluir build: " + e.getMessage());
        }
    }

    @Override
    public Build buscarPorId(int id) throws Exception {
        String sql = """
            SELECT b.id as build_id, b.nome_build, b.observacoes,
                   p.id as personagem_id, p.classe, p.nivel, p.vigor, p.mind, p.endurance,
                   p.strength, p.dexterity, p.intelligence, p.faith, p.arcane
            FROM build b
            INNER JOIN personagem p ON b.personagem_id = p.id
            WHERE b.id = ?
            """;

        try (Connection conn = Conexao.getConexao();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                Build build = montarBuild(rs);
                build.setEquipamentos(buscarEquipamentos(build.getId()));
                return build;
            } else {
                throw new Exception("Build com ID " + id + " não encontrada.");
            }
        } catch (SQLException e) {
            throw new Exception("Erro ao buscar build: " + e.getMessage());
        }
    }

    @Override
    public List<Build> listarTodos() throws Exception {
        List<Build> lista = new ArrayList<>();
        String sql = """
            SELECT b.id as build_id, b.nome_build, b.observacoes,
                   p.id as personagem_id, p.classe, p.nivel, p.vigor, p.mind, p.endurance,
                   p.strength, p.dexterity, p.intelligence, p.faith, p.arcane
            FROM build b
            INNER JOIN personagem p ON b.personagem_id = p.id
            ORDER BY b.nome_build
            """;

        try (Connection conn = Conexao.getConexao();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Build build = montarBuild(rs);
                build.setEquipamentos(buscarEquipamentos(build.getId()));
                lista.add(build);
            }
        } catch (SQLException e) {
            throw new Exception("Erro ao listar builds: " + e.getMessage());
        }
        return lista;
    }

    @Override
    public List<Build> buscarPorNome(String nome) throws Exception {
        List<Build> lista = new ArrayList<>();
        String sql = """
            SELECT b.id as build_id, b.nome_build, b.observacoes,
                   p.id as personagem_id, p.classe, p.nivel, p.vigor, p.mind, p.endurance,
                   p.strength, p.dexterity, p.intelligence, p.faith, p.arcane
            FROM build b
            INNER JOIN personagem p ON b.personagem_id = p.id
            WHERE b.nome_build LIKE ?
            ORDER BY b.nome_build
            """;

        try (Connection conn = Conexao.getConexao();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, "%" + nome + "%");
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Build build = montarBuild(rs);
                build.setEquipamentos(buscarEquipamentos(build.getId()));
                lista.add(build);
            }
        } catch (SQLException e) {
            throw new Exception("Erro ao buscar por nome: " + e.getMessage());
        }
        return lista;
    }

    @Override
    public List<Build> buscarPorClasse(String classe) throws Exception {
        List<Build> lista = new ArrayList<>();
        String sql = """
            SELECT b.id as build_id, b.nome_build, b.observacoes,
                   p.id as personagem_id, p.classe, p.nivel, p.vigor, p.mind, p.endurance,
                   p.strength, p.dexterity, p.intelligence, p.faith, p.arcane
            FROM build b
            INNER JOIN personagem p ON b.personagem_id = p.id
            WHERE p.classe LIKE ?
            ORDER BY b.nome_build
            """;

        try (Connection conn = Conexao.getConexao();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, "%" + classe + "%");
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Build build = montarBuild(rs);
                build.setEquipamentos(buscarEquipamentos(build.getId()));
                lista.add(build);
            }
        } catch (SQLException e) {
            throw new Exception("Erro ao buscar por classe: " + e.getMessage());
        }
        return lista;
    }

    // Métodos auxiliares privados
    private Build montarBuild(ResultSet rs) throws SQLException {
        Personagem personagem = new Personagem();
        personagem.setId(rs.getInt("personagem_id"));
        personagem.setClasse(rs.getString("classe"));
        personagem.setNivel(rs.getInt("nivel"));
        personagem.setVigor(rs.getInt("vigor"));
        personagem.setMind(rs.getInt("mind"));
        personagem.setEndurance(rs.getInt("endurance"));
        personagem.setStrength(rs.getInt("strength"));
        personagem.setDexterity(rs.getInt("dexterity"));
        personagem.setIntelligence(rs.getInt("intelligence"));
        personagem.setFaith(rs.getInt("faith"));
        personagem.setArcane(rs.getInt("arcane"));

        Build build = new Build();
        build.setId(rs.getInt("build_id"));
        build.setNomeBuild(rs.getString("nome_build"));
        build.setPersonagem(personagem);
        build.setObservacoes(rs.getString("observacoes"));

        return build;
    }

    private List<Equipamento> buscarEquipamentos(int buildId) throws SQLException {
        List<Equipamento> lista = new ArrayList<>();
        String sql = "SELECT * FROM equipamento WHERE build_id = ?";

        try (Connection conn = Conexao.getConexao();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, buildId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                String tipo = rs.getString("tipo");
                String nome = rs.getString("nome");
                String detalhe = rs.getString("detalhe");

                Equipamento eq = null;
                if ("Arma".equalsIgnoreCase(tipo)) {
                    eq = new Arma(nome, detalhe);
                } else if ("Armadura".equalsIgnoreCase(tipo)) {
                    eq = new Armadura(nome, detalhe);
                } else if ("Talisma".equalsIgnoreCase(tipo)) {
                    eq = new Talisma(nome, detalhe);
                }

                if (eq != null) {
                    eq.setId(rs.getInt("id"));
                    lista.add(eq);
                }
            }
        }
        return lista;
    }
}
package dao;

import model.Build;
import java.util.List;

public interface IBuildDAO {

    void cadastrar(Build build) throws Exception;

    void atualizar(Build build) throws Exception;

    void excluir(int id) throws Exception;

    Build buscarPorId(int id) throws Exception;

    List<Build> listarTodos() throws Exception;

    List<Build> buscarPorNome(String nome) throws Exception;

    List<Build> buscarPorClasse(String classe) throws Exception;
}
package view;

import dao.BuildDAO;
import model.*;

import java.util.List;
import java.util.Scanner;

public class Main {

    private static BuildDAO buildDAO = new BuildDAO();
    private static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        int opcao;

        do {
            System.out.println("\n========== GERENCIADOR DE BUILDS - ELDEN RING ==========");
            System.out.println("1 - Cadastrar nova Build");
            System.out.println("2 - Listar todas as Builds");
            System.out.println("3 - Buscar Build por ID");
            System.out.println("4 - Buscar Build por Nome");
            System.out.println("5 - Buscar Build por Classe");
            System.out.println("6 - Atualizar Build");
            System.out.println("7 - Excluir Build");
            System.out.println("0 - Sair");
            System.out.print("Escolha uma opção: ");
            
            opcao = sc.nextInt();
            sc.nextLine(); // limpar buffer

            try {
                switch (opcao) {
                    case 1 -> cadastrarBuild();
                    case 2 -> listarBuilds();
                    case 3 -> buscarPorId();
                    case 4 -> buscarPorNome();
                    case 5 -> buscarPorClasse();
                    case 6 -> atualizarBuild();
                    case 7 -> excluirBuild();
                    case 0 -> System.out.println("Saindo do sistema...");
                    default -> System.out.println("Opção inválida!");
                }
            } catch (Exception e) {
                System.out.println("Erro: " + e.getMessage());
            }

        } while (opcao != 0);

        sc.close();
    }

    private static void cadastrarBuild() throws Exception {
        System.out.println("\n----- CADASTRO DE BUILD -----");

        System.out.print("Nome da Build: ");
        String nomeBuild = sc.nextLine();

        System.out.print("Classe do personagem: ");
        String classe = sc.nextLine();

        System.out.print("Nível: ");
        int nivel = sc.nextInt();

        System.out.print("Vigor: ");
        int vigor = sc.nextInt();
        System.out.print("Mind: ");
        int mind = sc.nextInt();
        System.out.print("Endurance: ");
        int endurance = sc.nextInt();
        System.out.print("Strength: ");
        int strength = sc.nextInt();
        System.out.print("Dexterity: ");
        int dexterity = sc.nextInt();
        System.out.print("Intelligence: ");
        int intelligence = sc.nextInt();
        System.out.print("Faith: ");
        int faith = sc.nextInt();
        System.out.print("Arcane: ");
        int arcane = sc.nextInt();
        sc.nextLine();

        Personagem personagem = new Personagem(classe, nivel, vigor, mind, endurance,
                strength, dexterity, intelligence, faith, arcane);

        System.out.print("Observações: ");
        String observacoes = sc.nextLine();

        Build build = new Build(nomeBuild, personagem, observacoes);

        // Adicionar equipamentos
        System.out.print("Quantos equipamentos deseja adicionar? ");
        int qtd = sc.nextInt();
        sc.nextLine();

        for (int i = 0; i < qtd; i++) {
            System.out.println("\nEquipamento " + (i + 1));
            System.out.print("Tipo (1-Arma / 2-Armadura / 3-Talisma): ");
            int tipo = sc.nextInt();
            sc.nextLine();

            System.out.print("Nome do equipamento: ");
            String nomeEq = sc.nextLine();

            Equipamento eq = null;
            switch (tipo) {
                case 1 -> {
                    System.out.print("Categoria da arma: ");
                    String categoria = sc.nextLine();
                    eq = new Arma(nomeEq, categoria);
                }
                case 2 -> {
                    System.out.print("Parte da armadura: ");
                    String parte = sc.nextLine();
                    eq = new Armadura(nomeEq, parte);
                }
                case 3 -> {
                    System.out.print("Efeito do talismã: ");
                    String efeito = sc.nextLine();
                    eq = new Talisma(nomeEq, efeito);
                }
                default -> System.out.println("Tipo inválido, pulando...");
            }

            if (eq != null) {
                build.adicionarEquipamento(eq);
            }
        }

        buildDAO.cadastrar(build);
        System.out.println("\nBuild cadastrada com sucesso! ID: " + build.getId());
    }

    private static void listarBuilds() throws Exception {
        List<Build> lista = buildDAO.listarTodos();
        if (lista.isEmpty()) {
            System.out.println("\nNenhuma build cadastrada.");
        } else {
            System.out.println("\n----- LISTA DE BUILDS -----");
            for (Build b : lista) {
                System.out.println(b);
                System.out.println();
            }
        }
    }

    private static void buscarPorId() throws Exception {
        System.out.print("\nDigite o ID da build: ");
        int id = sc.nextInt();
        sc.nextLine();

        Build build = buildDAO.buscarPorId(id);
        System.out.println("\n" + build);
    }

    private static void buscarPorNome() throws Exception {
        System.out.print("\nDigite o nome (ou parte do nome): ");
        String nome = sc.nextLine();

        List<Build> lista = buildDAO.buscarPorNome(nome);
        if (lista.isEmpty()) {
            System.out.println("Nenhuma build encontrada.");
        } else {
            for (Build b : lista) {
                System.out.println(b);
                System.out.println();
            }
        }
    }

    private static void buscarPorClasse() throws Exception {
        System.out.print("\nDigite a classe: ");
        String classe = sc.nextLine();

        List<Build> lista = buildDAO.buscarPorClasse(classe);
        if (lista.isEmpty()) {
            System.out.println("Nenhuma build encontrada.");
        } else {
            for (Build b : lista) {
                System.out.println(b);
                System.out.println();
            }
        }
    }

    private static void atualizarBuild() throws Exception {
        System.out.print("\nDigite o ID da build que deseja atualizar: ");
        int id = sc.nextInt();
        sc.nextLine();

        Build buildAntiga = buildDAO.buscarPorId(id);
        System.out.println("Build atual:\n" + buildAntiga);

        System.out.println("\nDigite os novos dados:");
        cadastrarBuild(); // reutiliza o método de cadastro (simples)
        // Observação: essa versão simples exclui a antiga e cria uma nova.
        // Se quiser uma atualização mais elaborada depois, podemos melhorar.
    }

    private static void excluirBuild() throws Exception {
        System.out.print("\nDigite o ID da build que deseja excluir: ");
        int id = sc.nextInt();
        sc.nextLine();

        buildDAO.excluir(id);
        System.out.println("Build excluída com sucesso!");
    }
}